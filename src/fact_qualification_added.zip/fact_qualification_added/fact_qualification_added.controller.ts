import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';
import { FactQualificationAddedService } from './fact_qualification_added.service';
import { CreateFactQualificationAddedDto } from './dto/create-fact_qualification_added.dto';
import { UpdateFactQualificationAddedDto } from './dto/update-fact_qualification_added.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { writeFile } from 'fs/promises';

@Controller('fact_qualification_added')
export class FactQualificationAddedController {
  constructor(
    private readonly factQualificationAddedService: FactQualificationAddedService,
  ) {}

  @Post('create')
  create(
    @Body() createFactQualificationAddedDto: CreateFactQualificationAddedDto,
  ) {
    return this.factQualificationAddedService.create(
      createFactQualificationAddedDto,
    );
  }

  @Get('findAll')
  findAll() {
    return this.factQualificationAddedService.findAll();
  }

  @Get('findOne')
  findOne(@Body('qualificationAddedId') id: string) {
    return this.factQualificationAddedService.findOne(id);
  }

  @Post('update')
  update(
    @Body() updateFactQualificationAddedDto: UpdateFactQualificationAddedDto,
  ) {
    return this.factQualificationAddedService.update(
      updateFactQualificationAddedDto,
    );
  }

  @Delete('delete')
  remove(@Body('qualificationAddedId') id: string) {
    return this.factQualificationAddedService.remove(id);
  }

  @Post('image/:advisorId')
  @UseInterceptors(FileInterceptor('image'))
  imageUpload(@Body("qualificationAddedId")qualificationAddedId: string, @UploadedFile()file: Express.Multer.File) {
    console.log(file);
    let filePath = './client/'+qualificationAddedId+'.'+file.originalname.split('.')[1];
    console.log(filePath);
    writeFile(filePath,file.buffer);

    //Get the File Name
    let fileName = qualificationAddedId+'.'+file.originalname.split('.')[1];

    console.log(fileName);

    return this.factQualificationAddedService.uploadfile(fileName,qualificationAddedId)
    //Update the image path inside the table


  }
}
